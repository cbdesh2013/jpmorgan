DROP TABLE emp_rest;
drop sequence emp_master_seq;
create sequence emp_master_seq start with 100; 

CREATE Table emp_rest(

employee_id numeric(6) primary key,
	
name varchar(30),

salary numeric(6,2));