INSERT into emp_rest VALUES (1,'Smita',9999.00);
INSERT into emp_rest VALUES (2,'Rita',8888.00);
INSERT into emp_rest VALUES (3,'Raj',7777.00);
